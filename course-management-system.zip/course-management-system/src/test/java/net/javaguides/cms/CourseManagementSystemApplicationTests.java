package net.javaguides.cms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
